# moto widget and launcher

##  简述
手痒删了类原生自带的Android 12L launcher，所以找支持12L QuickSwitch多任务界面的launcher过程中，找到了[reiryuki](https://github.com/reiryuki) 的 moto launcher 和[android-hub](https://www.opencode.net/android-hub)的Derp Launcher 于是窃来修复一下就有了这个模块。

## 主要疗效
1. 修复了原最新的Moto 小部件 (4.06.33)；
2. 对喜欢或熟悉moto launcher的比较nice，但12L无法使用，可以选择停用；
3. 可以修复类原生12L的QuickSwitch多任务手势。


